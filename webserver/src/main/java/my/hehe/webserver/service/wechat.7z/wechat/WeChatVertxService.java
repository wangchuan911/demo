package my.hehe.webserver.service.wechat;


import io.vertx.codegen.annotations.ProxyGen;
import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import my.hehe.webserver.entity.wechat.messeage.request.RequestMesseage;
import my.hehe.webserver.entity.wechat.messeage.response.ResponseMesseage;
import my.hehe.webserver.service.wechat.impl.WeChatVertxServiceImpl;

@ProxyGen
public interface WeChatVertxService {
    public static final String SERVICE_ADDRESS = WeChatVertxService.class.getName();

    static WeChatVertxService create(Vertx vertx, JsonObject config) {
        return new WeChatVertxServiceImpl(vertx, config);
    }

    static WeChatVertxService createProxy(Vertx vertx, String address) {
        return new WeChatVertxServiceVertxEBProxy(vertx, address);
    }

    void receive(RequestMesseage message, Handler<AsyncResult<ResponseMesseage>> resultHandler);


}
