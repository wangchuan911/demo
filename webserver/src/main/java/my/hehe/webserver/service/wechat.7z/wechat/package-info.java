@ModuleGen(groupPackage = "my.hehe.webserver.service.wechat", name = "webserver")

package my.hehe.webserver.service.wechat;
import io.vertx.codegen.annotations.ModuleGen;