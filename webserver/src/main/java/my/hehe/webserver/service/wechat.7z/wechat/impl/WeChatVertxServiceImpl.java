package my.hehe.webserver.service.wechat.impl;


import io.vertx.core.AsyncResult;
import io.vertx.core.Future;
import io.vertx.core.Handler;
import io.vertx.core.Vertx;
import io.vertx.core.json.JsonObject;
import my.hehe.webserver.entity.wechat.messeage.MesseageTypeValue;
import my.hehe.webserver.entity.wechat.messeage.request.*;
import my.hehe.webserver.entity.wechat.messeage.response.ArticleMesseage;
import my.hehe.webserver.entity.wechat.messeage.response.ResponseMesseage;
import my.hehe.webserver.service.WeChatService;
import my.hehe.webserver.service.wechat.WeChatVertxService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class WeChatVertxServiceImpl implements WeChatVertxService {
    @Autowired
    @Qualifier("weChatService")
    WeChatService weChatService;

    private static final Logger logger = LoggerFactory.getLogger(WeChatVertxServiceImpl.class);
    private JsonObject config;

    public WeChatVertxServiceImpl(Vertx vertx, JsonObject config) {
        this.config = config;
    }

    @Override
    public void receive(RequestMesseage message, Handler<AsyncResult<ResponseMesseage>> resultHandler) {
        ResponseMesseage msgBody = null;
        String type = message.getMsgType();
        try {
            msgBody = weChatService.receive(message);
            resultHandler.handle(Future.succeededFuture(msgBody));
        } catch (Exception e) {
            resultHandler.handle(Future.failedFuture(e));
        }
    }
}
